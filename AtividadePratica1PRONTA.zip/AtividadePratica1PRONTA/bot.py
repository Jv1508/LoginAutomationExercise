
from botcity.web import WebBot
from src import setup_maestro
from src import funcoes_site
from config import *
from src import pega_data
from src import funcoes_log



def main():
     
     global condicao

     #conexão com o maestro.
     setup_maestro.maestro_()      
 
     # pega a data atual pela função data_log() e transforma em dd-MM-yyyy HH-mm-ss.
     data_agora = pega_data.data_log()      

     # transforma em uma string cm .txt no final para ser o nome do arquivo txt.
     nome_log = f'{data_agora}.txt'         

     #criando o arquivo e adicionando os primeiros textos do log
     funcoes_log.criar_arquivo_log(nome_log)
     funcoes_log.adicionar_info_log(nome_log, 'Inicio: Atividade Prática 1')
     funcoes_log.adicionar_info_log(nome_log, f'Data Atual {data_agora[0:10].replace('-','/')}')  #(substitui dd-MM-yyyy HH-mm-ss por dd/MM/yyyy).

     #Loop que continua enquanto variável condicao for True.
     while condicao:
        
        bot = WebBot()
        bot.driver_path = path_chromedriver
        
        try:
            #chama a função que executa o site e realiza o login e no final declara condicao false encerrando assim o loop.
            funcoes_site.abre_e_interage(bot,nome_log)  
            condicao = False

        except Exception as erro:
                # caso de algum erro, será avisado no log e o bot reinicia o loop do começo.                       
                print(f'Erro: {erro}')
                funcoes_log.adicionar_info_log(nome_log, 'Navegador Fechado, erro durante a execução, reiniciando programa')
                continue
        
    

     bot.wait(500)
     #log de encerramento, e avisa o maestro que a execucao foi realizada com sucesso.
     funcoes_log.adicionar_info_log(nome_log, 'Encerrando programa')

     bot.stop_browser()

     setup_maestro.fim_execucao()

  

def not_found(label):
    print(f"Element not found: {label}")


if __name__ == '__main__':   #chama a função main pra execução
    main()