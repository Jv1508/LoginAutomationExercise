path_chromedriver= r'C:\chromedriver-win64\chromedriver.exe'
link_site = 'https://practicetestautomation.com/practice-test-login/'
condicao = True
tentativas = 0
max_tentativas = 3
usuario = 'student'
senha = 'Password123'
caminho_logs =r'C:\Users\Usuario\Desktop\Práticas Estágio\Sprint 3 (BOT City)\Entregas da sprint\AtividadePratica1PRONTA\logs'
