from config import *
from botcity.web import WebBot, By
from src import funcoes_log
from bot import *


#configurando o web bot e caminho chromedriver
bot = WebBot()
bot.driver_path = path_chromedriver

def abre_e_interage(bot,nome_importado):
    """
    Abre o site, acha os elementos de username,password e botão pelo xpath. Insere as informações nos campos e clica no botão de login, e repete até 3 vezes caso o login seja falho;
    Além de escrever linhas desses processos no arquivo log criado nessa execução.
    Parâmetro(s): bot, nome_importado.
    """
    global tentativas,max_tentativas
    bot.browse(link_site)
    funcoes_log.adicionar_info_log(nome_importado,'Site Aberto')
    #Captura os campos username,password e botão de login do site pelo seu xpath
    username = bot.find_element('/html[1]/body[1]/div[1]/div[1]/section[1]/section[1]/div[1]/div[1]/input[1]', By.XPATH)
    password = bot.find_element('/html[1]/body[1]/div[1]/div[1]/section[1]/section[1]/div[1]/div[2]/input[1]', By.XPATH)
    botao = bot.find_element('/html[1]/body[1]/div[1]/div[1]/section[1]/section[1]/div[1]/button[1]', By.XPATH)
    funcoes_log.adicionar_info_log(nome_importado,'Elementos do site encontrados')

    #loop que se repete enquanto tentativas for menor que o limite de 3 tentativas.  
    while tentativas < max_tentativas:
        #insere o usuário e a senha de acordo com as variaveis do config.py e clica no botão de logout
        username.send_keys(usuario)
        funcoes_log.adicionar_info_log(nome_importado,'Nome de usuário inserido')
        bot.wait(300)
        password.send_keys(senha)
        funcoes_log.adicionar_info_log(nome_importado,'Senha inserida')
        botao.click()
        funcoes_log.adicionar_info_log(nome_importado,'Click no botão')
        #captura o botão de logout que aparece depois do login, caso ele seja achado encerra o loop,
        #caso não seja aumenta a variável tentativas e continua o loop até tentativas ser igual a 3.
        if bot.find("logout_button", matching=0.97, waiting_time=10000):
            funcoes_log.adicionar_info_log(nome_importado,f'Login realizado com sucesso')
            break
        tentativas += 1
        #Um log diferente para caso chegue ou não no limite de 3 tentativas.
        if tentativas != 3:
            funcoes_log.adicionar_info_log(nome_importado,f'Login falho, tentando novamente, tentativa {tentativas}/3')
        else:
            funcoes_log.adicionar_info_log(nome_importado,f'Login falho, limite de tentativas excedido: {tentativas}/3')
        

    

        