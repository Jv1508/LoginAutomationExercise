import os
from src import pega_data
from config import *
data_inicio_linha = pega_data.data_exibicao()

def criar_arquivo_log(nome_arquivo):
    """
    Cria um arquivo txt na pasta logs em cada execução.
    Parâmetro(s): nome_arquivo.
    """
    os.makedirs(caminho_logs, exist_ok=True)
    caminho_arquivo = os.path.join(caminho_logs, nome_arquivo)
    with open(caminho_arquivo, 'w') as arquivo:
        arquivo.write('')

def adicionar_info_log(nome_arquivo, informacao):
    """
    Escreve uma linha no arquivo txt da pasta logs.
    Parâmetro(s): nome_arquivo, informação.
    """
    caminho_arquivo = os.path.join(caminho_logs, nome_arquivo)
    with open(caminho_arquivo, 'a') as arquivo:
        #A data_inicio_linha é para a formatação pedida no log de "(dd/MM/yyyy mm:HH:ss):   ",
        # e após isso vem a informação um \n pra pular linha para proxima informação.
        arquivo.write(f'{data_inicio_linha} {informacao} .\n')