from datetime import datetime

def data_log():
    """
    Captura a data atual e retorna ela como string no formato string 'dd-MM-yyyy HH-mm-ss'.
    """
    data_atual = datetime.now()
    data_formatada = data_atual.strftime("%d-%m-%Y %H-%M-%S")
    return data_formatada
 
def data_exibicao():
    """
    Captura a data atual e retorna ela como string no formato string '(dd/MM/yyyy HH:mm:ss):   '.
    """
    data_atual = datetime.now()
    data_formatada = data_atual.strftime("(%d/%m/%Y %H:%M:%S):   ")
    return data_formatada