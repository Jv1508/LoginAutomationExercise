from botcity.maestro import *




def maestro_():
    """
    Faz a conexão com o maestro e mostra no console o task_id,
    e o execution.parameters.
    """
    BotMaestroSDK.RAISE_NOT_CONNECTED = False
    maestro = BotMaestroSDK.from_sys_args()
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

def fim_execucao():
    """
    Define o fim da execução e avisa que a task finalizou como sucesso.
    """
    maestro = BotMaestroSDK.from_sys_args()
    execution = maestro.get_execution()

    maestro.finish_task(
        task_id=execution.task_id,
        status=AutomationTaskFinishStatus.SUCCESS,
        message="Task Finished OK."
    )